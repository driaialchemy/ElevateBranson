# Prompt 10: Run-All Wrapper (Optional)

**Elevate Branson App Prompt Chain | Optional**
**Run in:** Claude Code, `C:\Users\msell\OneDrive\AIAlchemy\elevatebranson`
**When:** Use only after Prompts 0 to 2 have run cleanly.

Copy everything in the box below.

```
Execute phases 2 through 8 in order. Before each phase: re-read CLAUDE.md. After each phase: commit, push, then print one status line: "Phase N done | blockers: X | human tasks added: Y". Stop only for rule #6 violations or if the same blocker repeats across three phases.
```
