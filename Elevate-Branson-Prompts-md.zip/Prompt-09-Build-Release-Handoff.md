# Prompt 09: Build, Release, Handoff

**Elevate Branson App Prompt Chain | Prompt 9 of 9**
**Run in:** Claude Code, `C:\Users\msell\OneDrive\AIAlchemy\elevatebranson`
**When:** Paste into Claude Code after the previous phase has committed and pushed.

Copy everything in the box below.

```
GOAL
Prepare store builds and hand the project to the organization.

FORMAT
Configure EAS (app.json, eas.json, bundle IDs, icons, splash, permissions strings). Create docs/RELEASE_CHECKLIST.md: Apple Developer enrollment (nonprofit fee waiver if eligible), Google Play account, store listing copy, screenshots list, privacy policy and App Privacy / Data Safety answers (derived from the actual data the app collects), TestFlight and internal testing steps, review notes. Write docs/HANDOFF.md: architecture one-pager, accounts and who owns each, staff guide link, how to send a notification, how to update content, annual renewals, who to call.

GUARDRAILS
Rules from CLAUDE.md apply. Account ownership must be the organization, not an individual; flag this prominently. Do not run production builds or submit to stores without explicit instruction from me; run preview builds only.

CONTEXT
End state: org-owned accounts, staff-editable content, repeatable releases, everything in GitHub.
```
